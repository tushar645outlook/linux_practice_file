# Linux Practice Demo Files

This folder contains safe dummy files for Linux command practice.

## Contents
- `small/`: 1 KB, 10 KB, 100 KB files
- `medium/`: 1 MB, 5 MB, 10 MB files
- `large/`: 25 MB, 50 MB, 100 MB files
- `logs/`: sample application/authentication logs (not real system logs)
- `data/users.csv`: sample CSV dataset
- `data/services.txt`: sample service-status text

## Suggested practice
```bash
find . -type f -size +10M
find . -type f -printf '%s %p\n' | sort -n
du -ah . | sort -h
grep -i 'error' logs/application.log
awk -F, 'NR > 1 {print $2, $3, $4}' data/users.csv
find . -type f -name '*.bin' -exec ls -lh {} \;
tar -czf archive/practice.tar.gz small medium logs data
```

All files are dummy data. `auth.log.demo` is not a real authentication log.
